import axios from "axios";

const API_BASE_URL = "http://localhost:8000";

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});

export const pharmacyService = {
  // MAIN CHAT
  sendChatMessage: async (message, patient) => {
    return api.post("/chat", {
      user_id: patient.name, // must match backend
      message: message,
    });
  },

  // QUANTITY CONTINUATION
  sendQuantity: async (userId, medicine, quantity) => {
    return api.post("/chat/quantity", {
      user_id: userId,
      medicine: medicine,
      quantity: quantity,
    });
  },

  // FINAL CHECKOUT
  finalizeCheckout: async (patientId, items) => {
    return api.post("/finalize-checkout", {
      patient_id: patientId,
      items: items,
    });
  },

  getProducts: async () => {
    return api.get("/products");
  },
};
