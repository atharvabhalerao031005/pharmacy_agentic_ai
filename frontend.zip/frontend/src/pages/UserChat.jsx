import React, { useState, useRef, useEffect } from "react";
import { Send } from "lucide-react";
import { usePharmacy } from "../context/PharmacyContext";
import { pharmacyService } from "../services/api";

export default function UserChat() {
  const { patient, messages, setMessages, setAgentStatus } = usePharmacy();

  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [emergencyWord, setEmergencyWord] = useState(null);
  const [isThinking, setIsThinking] = useState(false);
  const [pendingMedicine, setPendingMedicine] = useState(null);

  // ✅ ADD THIS
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textOverride = null) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim()) return;

    // 1. PRESCRIPTION TRIGGER
    if (textToSend === "TRIGGER_RX_UPLOAD") {
      setIsUploadOpen(true);
      setInput("");
      return;
    }

    // 2. EMERGENCY INTERCEPTOR
    const RED_FLAGS = [
      "chest pain",
      "difficulty breathing",
      "heart attack",
      "stroke",
      "poison",
      "bleeding",
    ];
    const detected = RED_FLAGS.find((word) =>
      textToSend.toLowerCase().includes(word),
    );
    if (detected) {
      setEmergencyWord(detected);
      setInput("");
      return;
    }

    // 3. ADD USER MESSAGE
    const newMsg = {
      id: Date.now(),
      role: "user",
      content: textToSend,
      type: "text",
    };
    setMessages((prev) => [...prev, newMsg]);
    setInput("");
    setIsThinking(true);

    setAgentStatus({
      orchestrator: "thinking",
      physician: "idle",
      pharmacist: "idle",
      regulatory: "idle",
      inventory: "idle",
      billing: "idle",
      refill: "idle",
    });

    try {
      // 🔁 IF WAITING FOR QUANTITY
      if (pendingMedicine && !isNaN(textToSend)) {
        const response = await pharmacyService.sendQuantity(
          patient.name,
          pendingMedicine,
          parseInt(textToSend),
        );

        const backend = response.data;

        let aiMsg = {
          id: Date.now(),
          role: "ai",
          type: "text",
          content: backend.message,
        };

        if (backend.type === "order_success") {
          aiMsg.type = "checkout";
          aiMsg.medicine = backend.data?.product;
          aiMsg.quantity = backend.data?.quantity;
          aiMsg.price = backend.data?.total_price;
          setPendingMedicine(null);
        }

        setMessages((prev) => [...prev, aiMsg]);
        setIsThinking(false);
        return;
      }

      // 🔵 NORMAL CHAT FLOW
      const response = await pharmacyService.sendChatMessage(
        textToSend,
        patient,
      );
      const backend = response.data;

      if (backend.agents) setAgentStatus(backend.agents);

      let aiMsg = {
        id: Date.now(),
        role: "ai",
        type: backend.type || "text",
        content: backend.message,
      };

      // 🟡 ASK QUANTITY
      if (backend.type === "ask_quantity") {
        setPendingMedicine(backend.medicine);
      }

      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error("Backend error:", error);
      processAgentResponse(textToSend);
    }

    setIsThinking(false);
    return (
      <div className="flex flex-col h-full w-full bg-transparent overflow-hidden">
        <div className="flex-1 overflow-y-auto px-4 md:px-24 py-8 space-y-8 scrollbar-hide">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className="max-w-[85%] md:max-w-[65%] lg:max-w-[50%]">
                <div
                  className={`p-6 rounded-[2.5rem] text-[16px] ${
                    msg.role === "user"
                      ? "bg-blue-600/15 border-blue-400/30 backdrop-blur-3xl text-slate-900 rounded-tr-none"
                      : "bg-white/50 border-white/80 backdrop-blur-3xl text-slate-900 rounded-tl-none"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            </div>
          ))}

          <div ref={messagesEndRef} />
        </div>

        <div className="px-4 md:px-24 pb-12 pt-4">
          <div className="max-w-4xl mx-auto flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              className="flex-1 p-3 rounded-xl border"
              placeholder="Ask PharmaAgent anything..."
            />
            <button
              onClick={handleSend}
              className="p-3 bg-slate-900 text-white rounded-xl"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  };
}
